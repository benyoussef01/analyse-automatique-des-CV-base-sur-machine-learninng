<?php 


    include_once('script/config.php');
    function getOffres(){
        $con = getConnection();
        $sql = "SELECT * FROM offres";
        $exe = mysqli_query($con , $sql);
        return $exe;
    }