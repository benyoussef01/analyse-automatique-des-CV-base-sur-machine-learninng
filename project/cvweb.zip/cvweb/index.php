<?php 

    include 'script/init.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <div class="container mt-5">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-header bg-primary text-white text-center">Connexion</div>
                    <div class="card-body">
                        <?php 
                            if(isset($_POST['connect'])){
                                $username = $_POST['username'];
                                $password = $_POST['password'];
                                $user = mysqli_fetch_assoc(login($username, $password));
                                $role = $user['role'];
                                if($role === "ROLE_CANDIDAT"){
                                    session_start();
                                    $_SESSION['connecte'] = $user;
                                    header('location: candidat.php');
                                }else if ($role === "ROLE_RECRUTEUR"){
                                    session_start();
                                    $_SESSION['connecte'] = $user;
                                    header('location: recruteur.php');
                                }else if ($role === "ROLE_ADMIN"){
                                    session_start();
                                    $_SESSION['connecte'] = $user;
                                    header('location: admin.php');
                                }
                            }
                        ?>
                        <form action="" method="post" class="mb-3">
                            <div class="form-group">
                                <label for="username">Nom d'utilisateur</label>
                                <input type="text" class="form-control" name="username" id="username">
                            </div>
                            <div class="form-group">
                                <label for="password">Mot de passe</label>
                                <input type="password" class="form-control" name="password" id="password">
                            </div>
                            <button type="submit" name="connect" class="btn btn-sm btn-primary btn-block">se Connecter</button>
                        </form>
                        <a href="register.php" class="mt-5 text-center">Si vous n'avez pas un compte ? </a></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>