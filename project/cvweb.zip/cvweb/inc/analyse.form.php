<div class="card-body">
    <h3 class="text-center">Analyse du CVs</h3>
    <form action="" method="get">
        <div class="form-group"><label for="">Mot clés</label><input class="form-control" type="text" name="" id=""></div>
    </form>
    <button type="submit" class="btn btn-sm btn-primary btn-block">Analyse</button>
</div>